# -*- coding: UTF-8 -*-
# @Time : 2021/12/15 23:13
# @Author: 张永威
# @File : testCloud.py
# @Software : PyCharm

import jieba  #分词，词频统计，把一个句子分成多个词
from matplotlib import pyplot as plt  # 绘图功能，数据可视化
from wordcloud import WordCloud #词云，把字词拼成词云
from PIL import Image  #导入图片处理工具
import numpy as np  #导入矩阵运算
import sqlite3  # 数据库


#准备词云所需的文字,分词
con = sqlite3.connect('movie.db') #选择数据库
cur = con.cursor()
sql = 'select introduction from movie250'#数据库查询语句
data = cur.execute(sql)
text = ""
for item in data:#遍历获取到的信息
    text = text + item[0]
# print(text)
cur.close()
con.close()

cut = jieba.cut(text) #把获取的信息分好词
string = ' '.join(cut) #用空格间隔开
print(len(string)) #输出分词长度

#准备好词云需要用的图片
img = Image.open(r'.\static\assets\img\portfolio\portfolio-6.jpg') #打开遮罩图片
img_array = np.array(img)  #将图片转换为数组
wc = WordCloud(
    background_color='white', #设置好背景色
    mask=img_array,
    font_path="msyh.ttc" #字体所在位置：C:\Windows\Fonts
)

wc.generate_from_text(string)

#绘制图片
fig = plt.figure(1) #从第一个位置开始获取绘制
plt.imshow(wc) #显示图片
plt.axis('off') #是否显示坐标轴 off表示不显示

plt.show() #显示词云生成的图片

plt.savefig(r'.\static\assets\img\5.png',dpi=500)#保存生成的图片到此路径








