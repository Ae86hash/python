# -*- coding: UTF-8 -*-
# @Time : 2021/12/14 13:13
# @Author: 张永威
# @File : app.py
# @Software : PyCharm

from flask import Flask,render_template #导入Flask里面的flask包和render_template模板
import sqlite3 #导入数据库模块
app = Flask(__name__)

#两个函数都是访问首页
@app.route('/')#这个是flask的路由解析访问，类似url地址
def index():  #定义一个index函数用/访问首页
    return render_template('index.html')
@app.route('/index')
def home():  #定义函数用index/也能访问首页
    return render_template('index.html')  #直接调用index函数的返回


@app.route('/movie')
def moive():  #定义函数用/movie访问电影页
    datalist = []  #定义一个列表接收数据data
    con = sqlite3.connect("movie.db") #链接数据库movie.db
    cur = con.cursor()          #获取游标赋值给cur
    sql = "select * from movie250"   #执行sql语句进入该表
    data = cur.execute(sql)  #把查询出来的结果给data
    for item in data: #电影是item，循环遍历
        datalist.append(item)
    cur.close()
    con.close()
    return render_template('movie.html',movies=datalist)#把datalist的值赋给movies返回显示到网页上


@app.route('/score')
def score():  #定义函数用/score访问评分页
    score = []  #电影的评分，从数据库拿出来放到列表里
    num = []  #电影个数，每个评分所对应的一个电影，统计出的电影数量

    con = sqlite3.connect("movie.db")  # 链接数据库movie.db
    cur = con.cursor()  # 获取游标赋值给cur
    sql = "select score,count(score) from movie250 group by score"  # 执行sql语句进入该表,并统计该表的评分有多少个 xy轴分别为分数和电影个数，共两个列表
    data = cur.execute(sql)  # 把查询出来的结果给data
    for item in data:  # 电影是item，循环遍历
        score.append(item[0]) #从第一个列开始
        num.append(item[1]) #从第二个列开始
    cur.close()
    con.close()
    return render_template('score.html', score=score,num=num)  # 把datalist的值赋给movies返回显示到网页上



@app.route('/word')
def word():  #定义函数用/word访问词云页
    return render_template('word.html')


@app.route('/team')
def team():  #定义函数用team访问团队页6
    return render_template('team.html')


@app.route('/login')
def login():  #定义函数用team访问团队页
    return render_template('login.html')


@app.route('/register')
def register():  #定义函数用team访问团队页
    return render_template('register.html')


if __name__ == '__main__':
    app.run()
