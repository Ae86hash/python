# -*- coding: UTF-8 -*-
# @Time : 2021/12/20 21:40
# @Author: 张永威
# @File : testre.py
# @Software : PyCharm

from bs4 import BeautifulSoup
import urllib.request,urllib.error
import re


def main():
    baseurl = "https://movie.douban.com/top250?start="
    #1.爬取网页
    datalist = getData(baseurl)
    #savepath = "豆瓣电影Top250.xls"
    dbpath = "movie.db"

    #3.保存数据
    #saveData(datalist,savepath)
    # saveData2DB(datalist,dbpath)

    #askURL("https://movie.douban.com/top250?start=")

findLink = re.compile(r'<a href="(.*?)">')


def getData(baseurl): #接收url
    datalist = []
    for i in range(0,10):
        url = baseurl + str(i*25)
        html = askURL(url)

        soup = BeautifulSoup(html,"html.parser")
        for item in soup.findall('div',class_="item"):
            #print(item)
            data = []
            item = str(item)
            link = re.findall(findLink,item)[0]
            print(link)


    return datalist



def askURL(url):
    head = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36 Edg/93.0.961.38"
    }

    request = urllib.request.Request(url,headers=head)
    html = ""
    try:
        response = urllib.request.urlopen(request)#传递一个封装好的对象，里面的信息传递给response
        html = response.read().decode("utf-8") #读取response赋值给html
        #print(html)
    except urllib.error.URLError as e: #打印错误
        if hasattr(e,"code"):#打印编码问题错误
            print(e.code)
        if hasattr(e,"reason"):#打印原因
            print(e.reason)
    return html


if __name__ == "__main__":         #当程序执行时
#调用下面函数
    main()
    #init_db("movietest.db")
    # print("爬取完毕！")