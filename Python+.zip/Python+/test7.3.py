# -*- coding: UTF-8 -*-
# @Time : 2022/7/3 16:15
# @Author: 张永威
# @File : test7.3.py
# @Software : PyCharm

import sqlite3
#建库建表

# connect = sqlite3.connect("test73.db")#创建或链接数据库
# print("成功链接数据库")
# c= connect.cursor()#获取游标
# sql='''
# create table company
# (id int primary key not null,
# name text not null,
# age int not null,
# address char(50),
# salary real);
# '''
# c.execute(sql)#执行语句
# connect.commit()#提交数据库操作
# connect.close()#关闭数据库
# print("成功见表")

connect = sqlite3.connect("test73.db")#创建或链接数据库
print("成功链接数据库")
c= connect.cursor()#获取游标
sql='''
insert into company(id,name,age,address,salary)
values (3,"李四","35","深圳","15000")
'''

c.execute(sql)#执行语句
connect.commit()#提交数据库操作

print("成功插入")

sql1='''
select id ,name,age,address,salary from company'''
cursor=c.execute(sql1)#执行语句
for row in cursor:
    print("id= ",row[0])
    print("name= ", row[1])
    print("age= ", row[2])
    print("address= ", row[3])
    print("salary= ", row[4],"\n")
connect.close()#关闭数据库
print("查询完毕")