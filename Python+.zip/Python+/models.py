# -*- coding: UTF-8 -*-
# @Time : 2021/12/23 15:14
# @Author: 张永威
# @File : models.py
# @Software : PyCharm

import pymysql


con = pymysql.connect(
    host='localhost',
    port=3307,
    user='root',
    password='123456',
    db='pytest2',
    charset='utf8'
    ) # 链接数据库
cur=con.cursor()#数据库操作游标

def finduser():  ##提供user数据
    try:
        sql = "select * from user;"
        cur.execute(sql)
    except Exception as e:
        print("查询数据失败:", e)
    else:
        a = cur.fetchall()
        print(a)
        return a


def add_user(username, password):
    # sql 命令
    sql = "INSERT INTO user(uName, uPass) VALUES ('%s','%s')" %(username, password)
    # execute(sql)
    cur.execute(sql)
    # commit
    con.commit()  # 对数据库内容有改变，需要commit()，提交
    con.close()

# def is_null(username,password):
#     if(username==''or password==''):
#         return True
#     else:
#         return False
#
#
# def is_existed(username,password):
#     sql="SELECT * FROM user WHERE uName ='%s' and uPass ='%s'" %(username,password)
#     cur.execute(sql)
#     result = cur.fetchall()
#     if (len(result) == 0):
#         return False
#     else:
#         return True
#
# def exist_user(username):
#     sql = "SELECT * FROM user WHERE uName ='%s'" % (username)
#     cur.execute(sql)
#     result = cur.fetchall()
#     if (len(result) == 0):
#         return False
#     else:
#         return True


def Register(email,uname,psw):
    sql = 'select email from user where email = %s'
    cur.execute(sql, [email])
    rs = cur.fetchone()
    if rs is None:
        sql = 'insert into user(email,uName,uPass) values (%s,%s,%s)'
        cur.execute(sql, (email,uname,psw))
        con.commit()  # 进行数据的增删改查操作后，需提交到数据库执行
        return 1
    else:
        return "邮箱已被注册"


def Login(email,upass):
    sql = 'select uPass from user where email=%s'
    cur.execute(sql, [email])
    rs = cur.fetchone()
    if rs is None:  # b为None说明找不到用户名
        return "邮箱错误，登录失败"
    elif rs[0] == upass:
        return "登录成功"
    else:
        return "邮箱或者密码错误"