# -*- coding: UTF-8 -*-
# @Time : 2022/7/2 22:23
# @Author: 张永威
# @File : test7.21.py
# @Software : PyCharm

import xlwt

workbook = xlwt.Workbook(encoding="utf-8")#创建workbook对象
worksheet = workbook.add_sheet("99乘法表")#创建excel表
for i in range(0,9):
    for j in range(0,i+1):
        worksheet.write(i,j,"%d * %d= %d"%(i+1,j+1,(i+1)*(j+1)))
workbook.save("99.xls")