# -*- coding: UTF-8 -*-
# @Time : 2022/7/2 10:56
# @Author: 张永威
# @File : test7.2.py
# @Software : PyCharm

import urllib.request,urllib.error


url = "https://www.douban.com"
head= {"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/5"}
request = urllib.request.Request(url=url,headers=head)
try:
    response = urllib.request.urlopen(request)
    print(response.read().decode("utf-8"))
except Exception as result:
    print(result)