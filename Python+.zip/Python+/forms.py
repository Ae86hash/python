# -*- coding: UTF-8 -*-
# @Time : 2021/12/26 14:54
# @Author: 张永威
# @File : forms.py
# @Software : PyCharm
# from flask_wtf import FlaskForm
# from wtforms import StringField,PasswordField
# #用户注册
# class RegisterForm(FlaskForm):
#     email = StringField(label='邮箱',render_kw={
#         'class' : 'input is-large',
#         'placeholder' : 'Your Email'
#     })
#     username = StringField(label='用户名',render_kw={
#         'class': 'input is-large',
#         'placeholder': 'Your Name'
#     })
#     password = PasswordField(label='密码',render_kw={
#         'class': 'input is-large',
#         'placeholder': 'Your Password'
#     })